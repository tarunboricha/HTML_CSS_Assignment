﻿namespace SportsStoreManagementSystem.CoreMVC.Models
{
    public class SalesItemViewModel
    {
        public int SupId { get; set; }
        public int CustomerId { get; set; }
        public int ProductId { get; set; }
        public int Qty { get; set; }
        public int PricePerItem { get; set; }
    }
}
